package introduction_to_java.firstprogram;

public class Primitive_datatype {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        /*
         * Data types in java
         * 1.byte =23
         * 2.short=300
         * 3.int =3000
         * 4.float =3.1f
         * 5.long=300L
         * 6.char='A'
         * 7.double = 9.1
         * 8.boolean=true
         * 
         * DECLARATION OF VARIABLE
         * variable- it is the conatiner used to store the value based on ht data type
         * 
         * */
		byte age;
		//variable name=value
		age=20;
		//<datA type> variable name=value;
		byte age1=30;
		short srt=300;
		         int integer=3000;
		         float floated =3.1f;
		         long longer =300L;
		         char character='A';
		         double ddouble= 9.1;
		         boolean bln=true;
		
		
		System.out.println(age);
		System.out.println(age1);
		System.out.println(srt);
		System.out.println(integer);
		System.out.println(floated);
		System.out.println(longer);
		System.out.println(character);
		System.out.println(ddouble);
		System.out.println(bln);
	}

}
