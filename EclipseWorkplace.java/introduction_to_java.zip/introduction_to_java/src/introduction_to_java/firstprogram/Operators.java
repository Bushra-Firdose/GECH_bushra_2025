package introduction_to_java.firstprogram;

public class Operators {
	public static void main(String[] args) {
		/*Types of Operators in Java
		1.Arithmetic Operators
		2.Unary Operators
		3.Assignment Operator
		4.Relational Operators
		5.Logical Operators
		6.Ternary Operator
		7.Bitwise Operators
		8.Shift Operators
		9.instance of operator*/
	}
}
