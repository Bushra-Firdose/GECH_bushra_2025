package introduction_to_java.firstprogram;

public class Helloword {

	public static void main(String[] args) {
		System.out.println("HEllo world");
		
	}

}
